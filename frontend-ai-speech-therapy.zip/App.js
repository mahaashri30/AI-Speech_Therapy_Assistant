import React from "react";
import Recorder from "./components/Recorder";

function App() {
  return (
    <div className="App">
      <Recorder />
    </div>
  );
}

export default App;